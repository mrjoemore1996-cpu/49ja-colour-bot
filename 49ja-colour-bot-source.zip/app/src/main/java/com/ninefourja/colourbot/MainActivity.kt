package com.ninefourja.colourbot

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import org.json.JSONArray
import org.json.JSONObject
import java.text.NumberFormat
import java.util.Locale

private data class Entry(val colour: String, val time: Long)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme { ColourBotScreen() } }
    }
}

@Composable
private fun ColourBotScreen() {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("colour_bot", 0) }
    var stake by remember { mutableStateOf(prefs.getString("stake", "1000") ?: "1000") }
    var green by remember { mutableStateOf(true) }
    var blue by remember { mutableStateOf(true) }
    var red by remember { mutableStateOf(true) }
    var history by remember { mutableStateOf(loadHistory(prefs)) }
    val money = NumberFormat.getNumberInstance(Locale("en", "NG"))
    val selectedCount = listOf(green, blue, red).count { it }
    val amount = stake.toLongOrNull()?.coerceAtLeast(0) ?: 0L

    fun addResult(colour: String) {
        history = (listOf(Entry(colour, System.currentTimeMillis())) + history).take(100)
        saveHistory(prefs, history)
    }

    Scaffold { padding ->
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(padding).padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item {
                Text("49JA COLOUR BOT", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                Text("Colour history and stake tracker", color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            item {
                Card {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("Choose any stake amount", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                        OutlinedTextField(
                            value = stake,
                            onValueChange = { input ->
                                stake = input.filter { it.isDigit() }.take(12)
                                prefs.edit().putString("stake", stake).apply()
                            },
                            label = { Text("Stake per selected colour (₦)") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            listOf("500", "1000", "2000", "5000").forEach { preset ->
                                OutlinedButton(onClick = {
                                    stake = preset
                                    prefs.edit().putString("stake", stake).apply()
                                }) { Text("₦$preset") }
                            }
                        }
                        Text("Select colours to include in your stake estimate")
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Checkbox(checked = green, onCheckedChange = { green = it })
                            Text("🟢 Green")
                        }
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Checkbox(checked = blue, onCheckedChange = { blue = it })
                            Text("🔵 Blue")
                        }
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Checkbox(checked = red, onCheckedChange = { red = it })
                            Text("🔴 Red")
                        }
                        Divider()
                        Text("Selected total: ₦${money.format(amount * selectedCount)}", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                        Text("This is a tracker estimate only. It does not place bets.", style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
            item {
                Card {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("Record the result you saw", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                        Text("Tap one colour after each round. The app stores up to 100 entries on this phone.")
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(onClick = { addResult("Green") }, colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF168A45)), modifier = Modifier.weight(1f)) { Text("Green") }
                            Button(onClick = { addResult("Blue") }, colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2468C7)), modifier = Modifier.weight(1f)) { Text("Blue") }
                            Button(onClick = { addResult("Red") }, colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFC62828)), modifier = Modifier.weight(1f)) { Text("Red") }
                        }
                    }
                }
            }
            item {
                val total = history.size
                val g = history.count { it.colour == "Green" }
                val b = history.count { it.colour == "Blue" }
                val r = history.count { it.colour == "Red" }
                Card {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text("Recorded results", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                        Text("Total recorded: $total")
                        Text("🟢 Green: $g (${percent(g, total)}%)")
                        Text("🔵 Blue: $b (${percent(b, total)}%)")
                        Text("🔴 Red: $r (${percent(r, total)}%)")
                        Text("Percentages describe only the results you entered; they do not predict the next result.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
            item {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                    Text("Recent history", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                    TextButton(onClick = {
                        history = emptyList()
                        saveHistory(prefs, history)
                    }) { Text("Clear") }
                }
            }
            if (history.isEmpty()) {
                item { Text("No results recorded yet.") }
            } else {
                items(history) { entry ->
                    ListItem(
                        headlineContent = { Text(entry.colour, fontWeight = FontWeight.Medium) },
                        supportingContent = { Text(java.text.DateFormat.getDateTimeInstance().format(java.util.Date(entry.time))) },
                        leadingContent = {
                            val c = when (entry.colour) {
                                "Green" -> Color(0xFF168A45)
                                "Blue" -> Color(0xFF2468C7)
                                else -> Color(0xFFC62828)
                            }
                            Surface(color = c, shape = MaterialTheme.shapes.small, modifier = Modifier.size(14.dp)) {}
                        }
                    )
                    HorizontalDivider()
                }
            }
            item {
                Text("Reminder: Gambling involves risk. No pattern or analysis can guarantee a win. Only risk money you can afford to lose.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error)
            }
        }
    }
}

private fun percent(value: Int, total: Int): Int = if (total == 0) 0 else (value * 100 / total)

private fun loadHistory(prefs: android.content.SharedPreferences): List<Entry> {
    return try {
        val array = JSONArray(prefs.getString("history", "[]"))
        (0 until array.length()).map { i ->
            val item = array.getJSONObject(i)
            Entry(item.getString("colour"), item.getLong("time"))
        }
    } catch (_: Exception) { emptyList() }
}

private fun saveHistory(prefs: android.content.SharedPreferences, entries: List<Entry>) {
    val array = JSONArray()
    entries.forEach { entry ->
        array.put(JSONObject().put("colour", entry.colour).put("time", entry.time))
    }
    prefs.edit().putString("history", array.toString()).apply()
}
