# 49JA Colour Bot

An Android colour-result history and stake-estimate tracker for Green, Blue and Red.

## Features
- Enter any stake amount in naira.
- Select Green, Blue and/or Red to estimate the combined stake.
- Manually record the colour result observed each round.
- View counts and percentages from the results you entered.
- Keeps up to 100 recent entries on the phone.
- Builds an Android debug APK with GitHub Actions.

## Build the APK
1. Open the **Actions** tab in this GitHub repository.
2. Select **Build Android APK**.
3. Tap **Run workflow**, then **Run workflow** again.
4. Wait for the workflow to finish successfully.
5. Open the completed workflow run and download the `49ja-colour-bot-apk` artifact.
6. Extract the downloaded ZIP and install `app-debug.apk` on your Android phone. You may need to allow installation from your browser or file manager.

This app does not connect to a betting website, place bets, or guarantee predictions. Percentages are summaries of manually entered past results, not forecasts.
